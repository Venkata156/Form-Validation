const express = require('express');
const cors = require('cors');
var fs = require('fs');
const app = express();
app.use(cors());
app.use(express.json());
 

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
}); 
 

app.post('/api/reports', (req,res) => {
    
    // res.header("Access-Control-Allow-Origin", "*");
    // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

    console.log('This is post');

    const report = {
        requestor: req.body.requestor,
        report_name: req.body.report_name,
        txtid: req.body.txtid,
        email: req.body.email,
        priority: req.body.priority,
        replace1: req.body.replace1,
        replace2: req.body.replace2,
        replace3: req.body.replace3
    };

    var result ;

    fs.readFile("vendor_activitiy.SQL", 'utf8', function (err,data) {
        if (err) {
          return console.log(err);
        }

       if(report.replace1){
        data = data.replace(/%replace1%/g, report.replace1);
       }
       else{
        data = data.replace(/%replace1%/g, '');
       }
       if(data.replace2){
        data = data.replace(/%replace2%/g, report.replace2);
       }
       else{
        data = data.replace(/%replace2%/g, '');
       }
       if(report.replace3){
        data = data.replace(/%replace3%/g, report.replace3);
       }
       else{
        data = data.replace(/%replace3%/g, '');
       }

       data = data.replace(/'/g,'^');

       result= data;
 
    });

    var sql = require("mssql");

    // config for your database
    var config = {
        user: 'reporting_user',
        password: '3x7Gx0',
        server: 'USMEM-SQL01.internal.modetransportation.com\\QA', 
        database: 'reporting' 
    };

    let recordId;



    // connect to your database
    sql.close()
    sql.connect(config, function (err) {
       if (err) console.log(err);
        // create Request object
        var request = new sql.Request();
    
        // query to the database and get the records
        var report_request_query=`Insert into report_request (requestor, start, reportname,  txtid,email, status,priority) values ('${report.requestor}', getdate(), '${report.report_name}', '${report.txtid}','${report.email}',  'Requested','${report.priority}'); SELECT SCOPE_IDENTITY() AS id`;
        request.query(report_request_query, function (err, data) {
            
            if (err) console.log(err)
            recordId = data.recordset[0].id;
            console.log("hello in first insert");
            console.log(recordId);
            // send records as a response
            res.send(data.recordset[0]);
        });
    });// End SQL Connect

  
    
});// End Post


app.get('/api/reports', function (req, res) {
   
    console.log('This is get');
    res.send('Hello World');
});

var server = app.listen(5000, function () {
    console.log('Server is running..');
});
SELECT 	vendor_id,
	vendor_name
   FROM	vendor
where	vendor_id in (%replace3%)
into TEMP cinv_temp with no log;

--  ------------------ Get Payments
SELECT 	payments.payment_id,
	payments.payment_nbr,
	payments.payment_date,
	payment_detail.pmt_amt,
	payment_detail.pmtcntrl_fk,
	payment_detail.db_glacct_fk,
	payments.payment_to_fk,
	payments.rpt_glto

   FROM	payments, payment_detail

   WHERE	payments.payment_date between %replace1%  AND
	payments.status = 'P'   AND
	payments.payment_to = 'V'   AND
	payments.payment_to_fk IN ( SELECT vendor_id FROM cinv_temp )   AND
	payments.payment_id = payment_detail.payment_fk   AND
	payment_detail.pmtcntrl_flag = 'F'

into TEMP pmt_temp with no log;

--  ------------------ Get Vendor AP Invoice XRF
SELECT	*

   FROM 	vend_apinv_xrf

   WHERE	vendor_fk IN (SELECT vendor_id FROM cinv_temp)

into TEMP xrf_temp with no log;

--  ------------------ Get Paid apinv_pmtcntrl

SELECT DISTINCT apinvexp_fk

   FROM	apinv_pmtcntrl, pmt_temp

   WHERE	status = 'P' AND
	pmt_temp.pmtcntrl_fk=apinv_pmtcntrl.pmtcntrl_id

into TEMP pc_temp with no log;

--  ------------------ Get Paid AP Invoices
SELECT	ap_invoice.apinv_id,
	ap_invoice.apinv_nbr,
	ap_invoice.apinv_date,
	ap_invoice.original_amt,
	apinv_exp.adjexp_amt,
	ap_invoice.due_date,
	apinv_pmtcntrl.pmtcntrl_id,
	'P' as status,
	apinv_pmtcntrl.pmt_amt,
	apinv_exp.ref_nbr,
	ap_invoice.received_date,
	apinv_exp.trailer_nbr

   FROM	ap_invoice, apinv_exp, apinv_pmtcntrl, cust_invoice, custinv_exp

   WHERE	ap_invoice.apinv_id IN (SELECT apinv_fk FROM xrf_temp)   AND
	ap_invoice.status = 'A'   AND
--	ap_invoice.paid_amt > 0.00   AND
	ap_invoice.apinv_id = apinv_exp.apinv_fk   AND
	apinv_exp.apinv_exp_id = apinv_pmtcntrl.apinvexp_fk   AND
	apinv_exp.apinv_exp_id IN (SELECT apinvexp_fk FROM pc_temp) AND
	apinv_exp.custinv_exp_fk = custinv_exp.custinv_exp_id AND
	custinv_exp.custinv_fk = cust_invoice.custinv_id 


%replace2%

into TEMP ainvpd_temp with no log;

--  ------------------ Get Unpaid AP Invoices
SELECT	ap_invoice.apinv_id,
	ap_invoice.apinv_nbr,
	ap_invoice.apinv_date,
	ap_invoice.original_amt,
	apinv_exp.adjexp_amt,
	ap_invoice.due_date,
	apinv_exp.ref_nbr,
	ap_invoice.received_date,
	apinv_exp.trailer_nbr

   FROM	ap_invoice, apinv_exp, cust_invoice, custinv_exp

   WHERE	ap_invoice.apinv_id IN (SELECT apinv_fk FROM xrf_temp)   AND
	ap_invoice.apinv_date between %replace1%  AND
	ap_invoice.status = 'A'   AND
--	ap_invoice.paid_amt < 0.01 AND
	ap_invoice.apinv_id = apinv_exp.apinv_fk   AND
	apinv_exp.apinv_exp_id NOT IN (SELECT apinvexp_fk FROM pc_temp) AND
	apinv_exp.custinv_exp_fk = custinv_exp.custinv_exp_id AND
	custinv_exp.custinv_fk = cust_invoice.custinv_id 
--  if they want the data based on a specific set of office codes
%replace2%

into TEMP ainv_temp with no log;

--  ------------------ Merge paid invoices with payments table to prevent long transaction error

SELECT	apinv_nbr,
	apinv_date,
	ref_nbr,
	original_amt,
	adjexp_amt,
	due_date,
	status,
 	pmt_temp.payment_id,
	pmt_temp.payment_nbr,
	pmt_temp.payment_date,
	pmt_temp.pmt_amt,
	pmt_temp.db_glacct_fk,
	xrf_temp.vendor_fk,
	pmt_temp.payment_to_fk,
	pmt_temp.pmtcntrl_fk,
	ainvpd_temp.received_date,
	pmt_temp.rpt_glto,
	ainvpd_temp.trailer_nbr
	

   FROM	ainvpd_temp, xrf_temp, pmt_temp

   WHERE	ainvpd_temp.pmtcntrl_id = pmt_temp.pmtcntrl_fk AND
	ainvpd_temp.apinv_id = xrf_temp.apinv_fk

into TEMP invpmt_temp with no log;

--  -------------------- Create Report Table


CREATE temp TABLE 	tmpvendact_rpt2 (
	item_id		serial 	PRIMARY KEY,
	vendor_nbr	integer,
	vendor_name	varchar(40),
	apinv_nbr		varchar(20),
	invoice_date	date,
	ref_nbr		varchar(60),
	adjexp_amt	money (11,2),
	pmt_amt		money (11,2)	default 0.00,
	due_date		date,
	payment_nbr	integer,
	payment_date	date,
	status		char(1),
	gl_acct		integer,
	pmtcntrl_nbr	integer,
	received_date  date,
	rpt_glto char(1),
	trailer_nbr varchar(30)
	);

--  -------------------- Prepare the Report

insert into tmpvendact_rpt2
   SELECT 	0,
	cinv_temp.vendor_id,
	cinv_temp.vendor_name,
	ainv_temp.apinv_nbr,
	ainv_temp.apinv_date,
	ainv_temp.ref_nbr,
	ainv_temp.adjexp_amt,
	' ',
	ainv_temp.due_date,
	' ',
	' ',
	' ',
	' ',
	' ',
ainv_temp.received_date,
    ' ',
	ainv_temp.trailer_nbr
   FROM 	cinv_temp, ainv_temp, xrf_temp

   WHERE	cinv_temp.vendor_id =xrf_temp.vendor_fk AND ainv_temp.apinv_id = xrf_temp.apinv_fk ;


insert into tmpvendact_rpt2
   SELECT 	0,
	cinv_temp.vendor_id,
	cinv_temp.vendor_name,
	invpmt_temp.apinv_nbr,
	invpmt_temp.apinv_date,
	invpmt_temp.ref_nbr,
	invpmt_temp.adjexp_amt,
	invpmt_temp.pmt_amt,
	invpmt_temp.due_date,
	invpmt_temp.payment_nbr,
	invpmt_temp.payment_date,
	invpmt_temp.status,
	invpmt_temp.db_glacct_fk,
	invpmt_temp.pmtcntrl_fk,
  invpmt_temp.received_date,
  invpmt_temp.rpt_glto,
  invpmt_temp.trailer_nbr

   FROM 	cinv_temp, invpmt_temp

   WHERE	cinv_temp.vendor_id = invpmt_temp.payment_to_fk ;


--  -------------------- Retrieve Report Data
SELECT 	
	vendor_nbr,
	vendor_name,
	apinv_nbr,
	invoice_date,
	ref_nbr,
	adjexp_amt,
	pmt_amt,
	tmpvendact_rpt2.due_date,
	payment_nbr,
	payment_date,
	tmpvendact_rpt2.status,
	gl_acct,
	received_date,
	tmpvendact_rpt2.rpt_glto
	, cust_invoice.adjinv_amt
	, cust_invoice.adjtot_profit,tmpvendact_rpt2.trailer_nbr

   FROM tmpvendact_rpt2, cust_invoice
   where tmpvendact_rpt2.ref_nbr = cust_invoice.custinv_nbr


ORDER BY 1;

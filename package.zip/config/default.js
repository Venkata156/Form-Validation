module.exports = {
  apiHost: 'http://localhost:3001',
  apiResource: {
    legalcontent: {
      resource: 'content'
    },
    vendor: {
      resource: 'vendor'
    }
  }
}

module.exports = {
  apiHost: 'http://localhost:5000',
  apiResource: {
    legalcontent: {
      resource: 'content'
    },
    vendor: {
      resource: 'reporting'
    }
  }
}

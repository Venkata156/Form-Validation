module.exports = {
    "env": {
        "browser": true,
        "es6": true,
        "node": true,
        "jest": true,
        "amd": true
    },
    "extends": ['eslint:recommended', 'prettier', 'prettier/react', "plugin:react/recommended"],
    "parser": 'babel-eslint',
    "parserOptions": {
        "ecmaVersion": 6,
        "sourceType": "module",
        "ecmaFeatures": {
            "experimentalObjectRestSpread": true,
            "jsx": true
        }
    },
    "globals": {
        "__DEV__": true
    },
    "plugins": [
        "react", "prettier"
    ],
    "rules": {
        "linebreak-style": 'off',
        'unicorn/no-abusive-eslint-disable': 'off',
        "unicorn/filename-case": ["error", {"case": "kebabCase"}],
        'no-console':0,
        'unicorn/catch-error-name':'off',
        'react/prop-types': 'off',
        'react/forbid-component-props': 'off',
        'react/jsx-no-bind': 'warn',
        'react/no-array-index-key': 'warn',
        'react/no-string-refs': 'warn',
        'react/require-default-props': 'off',
        'import/no-unresolved': 'off',
        'import/no-unassigned-import': 'off',
        'import/prefer-default-export': 'off',
        'import/no-extraneous-dependencies': 'off'
        // 'prettier/prettier': [
        //     'error',
        //     {
        //         singleQuote: true,
        //         semi: false,
        //         bracketSpacing: false,
        //         printWidth: 100
        //     }
        // ],
    },
    "settings": {
        "react": {
          "createClass": "createReactClass", // Regex for Component Factory to use,
                                             // default to "createReactClass"
          "pragma": "React",  // Pragma to use, default to "React"
          "version": "15.0", // React version, default to the latest React stable release
          "flowVersion": "0.53" // Flow version
        }
    }
}
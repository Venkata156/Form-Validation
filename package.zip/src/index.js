import 'babel-polyfill'
import React from 'react'
import debug from 'debug'
import ReactDOM from 'react-dom'
import App from './app'

const dbg = debug('app:index')
dbg('inside app: index')
ReactDOM.render(<App />, document.getElementById('root'))

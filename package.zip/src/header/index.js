import config from 'config'
import debug from 'debug'
import React, {Component} from 'react'
import _ from 'lodash'
import axios from 'axios'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {NavLink, withRouter} from 'react-router-dom'
import AppBar from '@material-ui/core/AppBar'
import Menu from '@material-ui/core/Menu'
import MenuItem from '@material-ui/core/MenuItem'
import Button from '@material-ui/core/Button'
import Toolbar from '@material-ui/core/Toolbar'
import Popover from '@material-ui/core/Popover'
import Tooltip from '@material-ui/core/Tooltip'
import Typography from '@material-ui/core/Typography'
import IconButton from '@material-ui/core/IconButton'
import Dialog from '@material-ui/core/Dialog'
import DialogActions from '@material-ui/core/DialogActions'
import DialogContent from '@material-ui/core/DialogContent'
import DialogContentText from '@material-ui/core/DialogContentText'
import DialogTitle from '@material-ui/core/DialogTitle'
import Badge from '@material-ui/core/Badge'
import {withStyles} from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import KeyboardArrowDown from '@material-ui/icons/KeyboardArrowDown'
import * as layoutActions from '../layout/layout-redux'
import {
  getSessionStorage,
  isClientUserIdSet,
  addInsessionStorage,
  setAxiosHeader,
  isJson
} from '../shared/util'
import {SESSION_KEYS, HelpDocuments} from '../constants/constant'

const dbg = debug('app:top-nav')
const actions = {
  ...layoutActions,
}
dbg('la=%o', actions)

const styles = theme => {
  const primaryColor = theme.palette.secondary[500]
  const primaryBg = theme.palette.secondary.A400
  const activeIconFocus = theme.palette.iconFocus
  const navHeaderBg = theme.palette.navHeader
  return {
    primaryColor: {
      padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`,
      color: primaryColor
    },
    headerNavIcons: {
      float: 'right',
      boxShadow: 'none',
      backgroundColor: 'white',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      '&:focus': {
        background: activeIconFocus
      }
    },
    header: {
      backgroundColor: primaryBg,
      boxShadow: '0 6px 18px 0 rgba(144,164,183,0.22)',
      borderRight: '1px solid #DCDCDC',
      borderBottom: '4px solid #4452B6',
      top: '35px'
    },
    buttonWithFocus: {
      color: '#282E4D',
      fontFamily: 'Open Sans',
      fontSize: '12px',
      fontWeight: 'bold',
      letterSpacing: '-0.22px',
      lineHeight: '20px',
      '&:hover': {
        color: '#282E4D'
      },
      backgroundColor: 'transparent',
      border: 'none'
    },
    navHeader: {
      backgroundColor: navHeaderBg,
      boxShadow: 'none'
    },
    listTypography: {
      color: '#3F3F3F',
      padding: '12px',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      textDecoration: 'none'
    },

    navListContent: {
      color: '#3F3F3F',
      marginTop: '5%',
      width: '100%',
      marginLeft: '10%',
      marginRight: '25px'
    },
    labelAlign: {
      color: '#111111',
      fontFamily: 'Open sans',
      fontSize: '14px',
      marginRight: '40px'
    },
    activeMenu: {
      fontWeight: 'bold',
      color: '#111111',
      fontFamily: 'Open sans',
      fontSize: '14px',
      marginRight: '40px'
    },
    radioIcon: {
      height: '32px',
      fontSize: '1.5rem',
      color: '#0074D0'
    },
    fieldsetAlign: {
      overflowY: 'hidden',
      overflowX: 'hidden'
    },
    navToolBar: {
      width: '100%',
      alignSelf: 'center'
    },
    toolbarHeight: {
      minHeight: '0px'
    },
    navIconAlign: {
      display: 'flex',
      width: '100%',
      alignItems: 'center',
      height: '100%'
    },
    popoverMargin: {
      marginTop: '9px'
    },
    headertext: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '12px',
      fontWeight: 'bold',
      letterSpacing: '0.06px',
      lineHeight: '19px',
      '&:hover': {
        color: '#282E4D'
      }
    },
    loginButton: {
      color: '#FFFFFF',
      position: 'fixed',
      marginTop: '300px',
      marginLeft: '45.5%',
      height: '46px',
      width: '105px',
      borderRadius: '23px',
      backgroundColor: '#1A96B2',
      boxShadow: '0 2px 4px 0 rgba(0,0,0,0.34)',
      fontFamily: 'Open Sans',
      fontSize: '18px',
      fontWeight: '600',
      lineHeight: '24px',
      textAlign: 'center',
      '&:hover': {
        background: '#1A96B2'
      }
    },
    bar: {},
    checked: {
      color: '#FFFFFF',
      '& + $bar': {
        backgroundColor: '#FFFFFF'
      }
    },
    textdecoration: {
      textDecoration: 'none'
    },
    communitiesdiv: {
      height: '100%'
    },
    communitiesdivCommunitySelector: {
      height: '100%'
    },
    communitiesicondiv: {
      float: 'left',
      display: 'inline-flex'
    },
    communitiesicon: {
      color: '#DCDCDC',
      height: '50px',
      width: '50px'
    },
    communitiesiconleft: {
      color: '#42A5F5'
    },
    communitiesiconright: {
      color: '#FFA726',
      marginLeft: '-18%'
    },
    communitiestext: {},
    navmenudiv: {
      height: '100%',
      paddingTop: '10%',
      borderLeft: '1px solid #DCDCDC',
      paddingLeft: '15%',
      borderRight: '1px solid #DCDCDC'
    },
    cursor: {
      cursor: 'pointer'
    },
    aboutdivborder: {
      width: '20%',
      height: '100%',
      paddingLeft: '1.5%',
      paddingTop: '1.5%',
      borderRight: '1px solid #DCDCDC',
      borderLeft: '1px solid #DCDCDC'
    },
    subheader: {
      borderTop: '1px solid #DCDCDC',
      borderBottom: '1px solid #DCDCDC',
      backgroundColor: '#44A67F'
    },
    avatar: {
      margin: 22
    },
    bigAvatar: {
      width: 60,
      height: 60
    },
    subheadertext: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '16px',
      fontWeight: 'bold',
      lineHeight: '20px'
    },
    daterangeicon: {
      height: '40px',
      width: '40px'
    },
    daterage: {
      fontSize: '12px',
      fontWeight: '600',
      lineHeight: '17px'
    },
    subheadertitle: {
      fontSize: '24px',
      lineHeight: '33px'
    },
    user: {
      paddingTop: '20%',
      paddingLeft: '8%'
    },
    count: {
      color: '#797979',
      fontFamily: '"Open Sans"',
      fontSize: '18px',
      fontWeight: 'bold',
      lineHeight: '20px',
      paddingTop: '18px'
    },
    downarrow: {
      marginLeft: '10px',
      color: '#3d86ff'
    },
    admindiv: {},
    admindivForCommunitySelector: {
      height: '100%',
      borderLeft: '1px solid #DCDCDC',
      borderRight: '1px solid #DCDCDC',
      textAlign: 'center',
      verticalAlign: 'middle'
    },
    admintextForCommunitySelector: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '24px',
      fontWeight: '600',
      lineHeight: '28px',
      paddingTop: '3%',
      paddingLeft: '3%',
      textAlign: 'center',
      verticalAlign: 'middle'
    },
    admintext: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '24px',
      fontWeight: '600',
      lineHeight: '28px',
      marginTop: '14px',
      marginBottom: '13px'
    },
    datelable: {
      fontSize: '12px',
      fontWeight: 'bold',
      lineHeight: '24px'
    },
    ribbonLabel: {
      height: '19px',
      color: '#5A6183',
      fontFamily: 'Open Sans',
      fontSize: '12px',
      fontWeight: 'bold',
      letterSpacing: '0.06px',
      lineHeight: '19px'
    },
    calicon: {
      height: '20px',
      width: '18px'
    },
    sublable: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      fontWeight: 'bold',
      letterSpacing: '0.06px',
      lineHeight: '19px'
    },
    gridBorder: {
      borderRight: '1px solid #DCDCDC'
    },
    gridHeight: {
      height: '56px'
    },
    headerIcons: {
      height: '24px',
      width: '24px'
    },
    badgeStyle: {
      backgroundColor: '#AD4AD9',
      color: '#ffffff',
      border: '1px solid #E5E7EC',
      width: '21px',
      height: '22px',
      marginTop: '7px'
    },
    lagGridStyle: {
      borderRight: '1px solid #DCDCDC'
    },
    calIconStyle: {
      paddingLeft: '4%'
    },
    alertStyle1: {
      color: '#282E4D',
      fontWeight: 'bold',
      fontSize: '16px',
      fontFamily: 'Open Sans',
      textDecoration: 'none'
    },
    alertStyle: {
      color: '#0E55CA',
      fontFamily: 'Open Sans',
      fontSize: '13px',
      fontWeight: 600,
      lineHeight: '21px',
      textDecoration: 'underline',
      textAlign: 'center'
    },
    secContainer: {
      paddingLeft: '12px',
      paddingTop: '12px',
      paddingRight: '12px',
      borderBottom: '1px solid #E8E8E8',
      cursor: 'pointer'
    },
    alertNameStyle: {
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '14px'
    },
    moreResultsStyle: {
      width: '100%',
      color: '#0E55CA',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      fontWeight: 600,
      textAlign: 'center',
      padding: '4%',
      textDecoration: 'underline',
      cursor: 'pointer'
    },
    noResultStyle: {
      width: '100%',
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      fontWeight: 600,
      textAlign: 'center',
      padding: '4%'
    },
    managementStyles: {
      paddingLeft: '15px',
      paddingBottom: '12px',
      paddingTop: '15px',
      color: '#282E4D',
      fontSize: '14px',
      fontFamily: 'Open Sans',
      textDecoration: 'none'
    },
    configurationStyles: {
      padding: '15px',
      color: '#282E4D',
      fontWeight: 'bold',
      fontSize: '16px',
      fontFamily: 'Open Sans',
      textDecoration: 'none'
    },
    filterStyle: {
      color: '#5A6183',
      fontWeight: 'bold',
      fontSize: '16px',
      fontFamily: 'Open Sans',
      textDecoration: 'none'
    },
    dialogheadertext: {
      color: '#5F606E',
      fontFamily: 'Open Sans',
      fontSize: '36px',
      fontWeight: '300',
      letterSpacing: '-0.58px',
      lineHeight: '49px'
    },
    simplifiedDialog: {
      maxWidth: '682px',
      border: '1px solid #E8E8E8',
      borderRadius: '4px',
      backgroundColor: '#FFFFFF',
      boxShadow: '0 2px 34px 0 rgba(0,0,0,0.19)',
      top: '50px'
    },
    advancedDialog: {
      maxWidth: '1366px',
      border: '1px solid #E8E8E8',
      borderRadius: '4px',
      backgroundColor: '#FFFFFF',
      boxShadow: '0 2px 34px 0 rgba(0,0,0,0.19)',
      top: '50px'
    },
    dialogHeaderbutton: {
      color: '#0E55CA',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      width: '110%',
      backgroundColor: 'transparent',
      border: 'none',
      '&:focus': {
        outline: '5px auto -webkit-focus-ring-color !important'
      },
      fontWeight: '600',
      lineHeight: '19px',
      textAlign: 'centre',
      cursor: 'pointer'
    },
    button: {
      border: '1px solid #266DCE',
      borderRadius: '4px',
      boxShadow: '0 2px 8px 0 rgba(0,0,0,0.18)',
      fontFamily: 'open sans',
      fontSize: '16px',
      fontWeight: 'bold',
      letterSpacing: '-0.26px',
      textTransform: 'capitalize'
    },
    menuitem: {
      width: '153px',
      borderBottom: '1px solid #ECEEF0',
      cursor: 'pointer'
    },
    menuListStyles: {
      paddingBottom: '0px',
      paddingTop: '0px'
    }
  }
}
class topNav extends Component {
  constructor(props) {
    super(props)

    this.state = {
      value: 0,
      iscommunity: false,
      open: false,
      helpOpen: false,
      settingsOpen: false,
      hideHeader: false,
      anchorEl: null,
      alertAnchorEl: null,
      helpAnchorGear: null,
      anchorOriginVertical: 'bottom',
      anchorOriginHorizontal: 'center',
      transformOriginVertical: 'top',
      transformOriginHorizontal: 'center',
      positionLeftHelp: 1000, // Same as above
      anchorReference: 'anchorEl',
      imageIndex: 0,
      communityDialogOpen: true,
      accountStructureDialog: false,
      externalUser: false,
      notificationList: [],
      DateRange: '',
      Lag: '',
      SimplifiedView: true,
      daterageSelect: 2
    }
    this.handleSettingsPopoverClick = this.handleSettingsPopoverClick.bind(this)
    this.handleSettingsRequestClose = this.handleSettingsRequestClose.bind(this)
    this.handleHelpPopoverClick = this.handleHelpPopoverClick.bind(this)
    this.handleHelpRequestClose = this.handleHelpRequestClose.bind(this)
    this.handleCommunityChange = this.handleCommunityChange.bind(this)
    this.handleCommunitySelectorClose = this.handleCommunitySelectorClose.bind(this)
    this.handleAlertClick = this.handleAlertClick.bind(this)
    this.handleClose = this.handleClose.bind(this)
    this.handleGearClick = this.handleGearClick.bind(this)
    this.handleGearClose = this.handleGearClose.bind(this)
    this.updateAlertNotifications = this.updateAlertNotifications.bind(this)
    this.handleView = this.handleView.bind(this)
    this.alertClose = this.alertClose.bind(this)
    this.handledaterageSelect = this.handledaterageSelect.bind(this)
    this.handleHeaderChange = this.handleHeaderChange.bind(this)
  }

  loadFile(fileName) {
    setAxiosHeader(axios)
    axios
      .get(fileName, {
        responseType: 'arraybuffer',
        headers: {
          Accept: 'application/pdf'
        }
      })
      .then(response => {
        let file = new Blob([response.data], {type: 'application/pdf'})
        let fileURL = URL.createObjectURL(file)
        window.open(fileURL)
      })
    this.setState({
      helpOpen: false
    })
  }

  handleChange(e, value) {
    e.stopPropagation()
    this.setState({value: value})
  }
  handleCommunityChange(e) {
    e.stopPropagation()
    this.setState(
      {communityDialogOpen: false, accountStructureDialog: true, SimplifiedView: true},
      this.handleEnableCommunitySelector
    )
  }
  handleHeaderChange(headerFlag) {
    this.setState({hideHeader: headerFlag})
  }
  handleView(e) {
    e.stopPropagation()
    let {SimplifiedView} = this.state
    this.setState({SimplifiedView: SimplifiedView ? false : true})
  }
  handleEnableCommunitySelector() {
    this.setState({communityDialogOpen: true})
  }
  handleCommunitySelectorClose() {
    let accountstructure
    let selectedAccountStructure = JSON.parse(
      getSessionStorage(SESSION_KEYS.UserSelectedUserFilter)
    )
    let name, cmlist, cmlen
    let funding = JSON.parse(getSessionStorage(SESSION_KEYS.UserSelectedFundingType))
    if (!_.isEmpty(selectedAccountStructure)) {
      accountstructure = _.head(selectedAccountStructure)
      let communities = this.getFormattedCommunityList(accountstructure)
      name = accountstructure.accountStructureName
      cmlist = communities
      cmlen = communities.length
    } else {
      name = ''
      cmlist = ''
      cmlen = ''
      funding = ''
    }

    this.setState({
      communityDialogOpen: false,
      menutext: name,
      cmlist: cmlist,
      cmlen: cmlen,
      funding: funding
    })
    addInsessionStorage(SESSION_KEYS.CommunityIsSelected, true)
  }

  handleHelpPopoverClick(e) {
    let isExternalUser = false
    let userName = getSessionStorage(SESSION_KEYS.PreferredUsername)
    if (!_.isNil(userName) && _.includes(userName, '@')) {
      isExternalUser = true
    } else {
      isExternalUser = false
    }

    this.setState({
      helpOpen: true,
      anchorEl: e.target,
      externalUser: isExternalUser
    })
  }

  handleSettingsPopoverClick(e) {
    this.setState({
      settingsOpen: true,
      anchorEl: e.target
    })
  }

  handleHelpRequestClose() {
    this.setState({
      helpOpen: false
    })
  }

  handleSettingsRequestClose() {
    this.setState({
      settingsOpen: false
    })
  }

  handleAlertClick(event) {
    event.stopPropagation()
    this.setState({
      alertAnchorEl: event.currentTarget
    })
  }

  handleClose() {
    this.setState({
      accountStructureDialog: false,
      SimplifiedView: true
    })
  }

  alertClose() {
    this.setState({
      alertAnchorEl: false
    })
  }

  handleGearClick(event) {
    event.stopPropagation()
    this.setState({
      helpAnchorGear: event.currentTarget
    })
  }

  handleGearClose() {
    this.setState({
      helpAnchorGear: null
    })
  }
  handledaterageSelect(value) {
    this.setState({
      daterageSelect: value
    })
    this.props.handleReload()
  }

  async fetchAlertNotifications() {
    const {session} = this.props
    if (session && session.token && isClientUserIdSet()) {
      let clientID = getSessionStorage(SESSION_KEYS.UserClientId)
      let userId = getSessionStorage(SESSION_KEYS.LoggedInUserId)
      const url = `${config.apiHost}/${config.apiResource.client.resource}/${clientID}/${
        config.apiResource.user.resource
      }/${userId}/${config.apiResource.alertnotifications.resource}`
      await this.props.fetchAlertNotifications(url)
    }
  }

  async updateAlertNotifications() {
    const {session} = this.props
    if (session && session.token && isClientUserIdSet()) {
      const clientId = getSessionStorage(SESSION_KEYS.UserClientId)
      let userId = getSessionStorage(SESSION_KEYS.LoggedInUserId)
      const url = `${config.apiHost}/${config.apiResource.client.resource}/${clientId}/${
        config.apiResource.user.resource
      }/${userId}/${config.apiResource.alertnotifications.resource}`
      let data = []
      data.push({name: 'notification'})
      this.props.history.push('/alert/review')
      if (_.size(this.state.notificationList) != 0) {
        await this.props.updateAlertNotifications({url: url, id: userId, data: data})
      }
      this.fetchAlertNotifications()
      this.setState({alertAnchorEl: null})
    }
  }

  async fetchUserSpace() {
    if (
      !isJson(getSessionStorage(SESSION_KEYS.BIRST_SPACES)) ||
      _.isEmpty(JSON.parse(getSessionStorage(SESSION_KEYS.BIRST_SPACES)).rows)
    ) {
      let userClientId = getSessionStorage(SESSION_KEYS.UserClientId)
      const spacesUrl = `${config.apiHost}/${config.apiResource.client.resource}`
      const userSpacesUrl = `${spacesUrl}/${userClientId}/spaces`
      let result = await lookupspacereducer.actions.fetchUserSpaces(userSpacesUrl)
      if (result && result.rows && !_.isEmpty(result.rows)) {
        addInsessionStorage(SESSION_KEYS.BIRST_SPACES, result)
        addInsessionStorage(SESSION_KEYS.CommunityIsSelected, true)
      } else {
        this.props.history.push('UnAuthorized') // Error Page
      }
    }
  }

  render() {
    dbg('render: props=%o', this.props)
    const {classes, session} = this.props
    let encoded = getSessionStorage(SESSION_KEYS.UserAuthToken)
    const decoded = encoded && jwtDecode(encoded)
    if (decoded) {
      decoded.preferred_username = `${decoded.family_name}, ${decoded.given_name}`
      session.token = {decoded}
    }

    const {
      helpOpen,
      anchorEl,
      alertAnchorEl,
      helpAnchorGear,
      externalUser,
      anchorOriginHorizontal,
      anchorOriginVertical,
      transformOriginVertical,
      transformOriginHorizontal,
      accountStructureDialog,
      SimplifiedView,
      hideHeader
    } = this.state

    let permission = JSON.parse(getSessionStorage(SESSION_KEYS.UserPermission))
    let adminIconFlag = _.includes(permission, '_functionality_AdminIcon')
    const docsPath = `${config.apiHost}/documents/` // This should be set to appropriate path in future if using S3 location
    //const tokenQueryString = session.token ? `?t=${encoded}` : ''

    return (
      <div >
      
            <AppBar className={classes.header} position="fixed">
              <Toolbar classes={{root: classes.toolbarHeight}}>
                <Grid container spacing={0} justify={'center'} alignItems={'center'}>
                  <Grid item xl={12} lg={12} md={8} sm={6} xs={6}>
                  <Grid item xl={11} lg={11} md={11} sm={11} xs={11}>
                  <Grid
                    container
                    spacing={0}
                    justify={'center'}
                    alignItems={'center'}
                  >
                    <Grid item xl={12} lg={12} md={12} sm={12} xs={12}>
                      <Typography
                        style={{
                          float: 'left',
                          color: '#5A6183',
                          fontFamily: 'Open Sans',
                          fontSize: '12px',
                          fontWeight: 'bold',
                          letterSpacing: '0.06px'
                        }}
                      >
                      menu1
                      </Typography>
                    </Grid>
                    <Grid
                      item
                      xl={12}
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                      className={classes.communitiestext}
                    >
                      menu2
                    </Grid>
                  </Grid>
                </Grid>
                  </Grid>
                </Grid>
              </Toolbar>
            
            </AppBar>
       
      </div>
    )
  }

}

export default withRouter(
  connect(
    state => {
      dbg('connect: state=%o', state)
      return {
        layout: state.layout,
        session: state.session,
      }
    },
    dispatch => {
      dbg('connect: actions=%o', actions)
      return bindActionCreators(actions, dispatch)
    }
  )(withStyles(styles)(topNav))
)

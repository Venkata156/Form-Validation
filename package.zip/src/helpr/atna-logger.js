import debug from 'debug'
import axios from 'axios'
import config from 'config'
import {setAxiosHeader} from '../shared/util'

const dbg = debug('logger:atna')

export async function Log(data) {
  setAxiosHeader(axios)
  axios
    .post(`${config.apiHost}/audit-Log`, data)
    .then(res => {
      dbg('res=%o', res)
    })
    .catch(err => {
      dbg('err=%o', err)
    })
}

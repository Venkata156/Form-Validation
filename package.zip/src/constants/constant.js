export const Constant = {
  MODULE: 'newDashboards',
}

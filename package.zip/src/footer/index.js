import React, {Component} from 'react'
import debug from 'debug'
import {withStyles} from '@material-ui/core/styles'
//import config from 'config'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {withRouter} from 'react-router-dom'
import * as layoutActions from '../layout/layout-redux'

const dbg = debug('app:footer')
const styles = theme => ({
  paper: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular
  },
  drawerRoot: {
    background: 'linear-gradient(45deg, #c77800 40%, #ffd95b 80%)',
    borderRadius: 3,
    border: 0,
    color: 'white',
    padding: '0 30px',
    boxShadow: '0 3px 5px 2px rgba(255, 105, 135, .3)'
  },
  root: {
    borderTop: '1px solid #DCDCDC',
    flexWrap: 'wrap',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    background: '#fff',
    padding: '1%'
  },
  footerText: {
    color: '#3F3F3F',
    fontSize: '14px',
    display: 'inline-block'
  },
  closeButton: {
    fontFamily: 'Open Sans',
    fontSize: '14px',
    borderRadius: '16px',
    textTransform: 'capitalize'
  },
  headertext: {
    height: '24px',
    width: '100px',
    color: '#161830',
    fontFamily: 'Open Sans',
    fontSize: '14px',
    fontWeight: '600',
    lineHeight: '24px'
  },
  rowtext: {
    height: '24px',
    width: '100px',
    color: '#161830',
    fontFamily: 'Open Sans',
    fontSize: '16px',
    lineHeight: '24px'
  },
  rowtextRed: {
    height: '24px',
    width: '100px',
    color: 'Red',
    fontFamily: 'Open Sans',
    fontSize: '16px',
    lineHeight: '24px'
  },
  item: {
    flex: 1,
    marginLeft: '2%'
  },
  flexrow: {
    display: 'flex',
    flexDirection: 'row'
  },
  flexcol: {
    display: 'flex',
    flexDirection: 'column'
  },
  buttonWithFocus: {
    backgroundColor: 'transparent',
    border: 'none',
    '&:focus': {
      outline: '5px auto -webkit-focus-ring-color !important'
    }
  },
  verbiageDiv: {
    background: '#FFA726',
    height: '30%',
    textAlign: 'center'
  },
  verbiageContent: {
    color: 'white',
    paddingTop: '1%',
    fontWeight: '600'
  }
})

class footer extends Component {
  constructor(props) {
    super(props)
    this.state = {
      open: false,
    }
  }

  render() {
    dbg('render: props=%o', this.props)
    const { classes } = this.props
   
    return (
      <div>
        <div className={classes.root}>
          <div className={classes.flexrow}>
            <div className={classes.item}>
              <img
                src={''}
                alt="hdms-Logo"
                style={{paddingBottom: '4px', height: '22px', width: '150px'}}
              />
              <span style={{marginLeft: '10px', marginRight: '10px'}}>|</span>
              <img
                src={''}
                alt="footer-logo"
                style={{paddingBottom: '4px', height: '22px', width: '66px'}}
              />
              <span style={{fontSize: '16px', marginLeft: '10px', fontFamily: 'open Sans'}}>
                <strong style={{fontWeight: '600', color: '#414141'}}>
                  © {new Date().getFullYear()}
                </strong>
              </span>
            </div>
            
          </div>
        </div>
      </div>
    )
  }
}
export default withRouter(
  connect(
    state => {
      dbg('connect: state=%o', state)
      return {
        layout: state.layout,
      }
    },
    dispatch => {
      dbg('connect: actions=%o', layoutActions)
      return bindActionCreators({...layoutActions}, dispatch)
    }
  )(withStyles(styles)(footer))
)

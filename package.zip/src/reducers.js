import debug from 'debug'
import {combineReducers} from 'redux'
import {reducer as form} from 'redux-form'
import clientredux from './reducers/shared/vendor-reducer'
const dbg = debug('app:reducers')

const reducers = {
  form,
  vendors: clientredux.reducer,
  // communities: communityredux.reducer,
  // clients: clientredux.reducer,
}

dbg('reducers=%o', reducers)

export default combineReducers(reducers)

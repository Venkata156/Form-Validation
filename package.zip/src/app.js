import React, {Component} from 'react'
import debug from 'debug'
import {Provider} from 'react-redux'
import configureStore from './store/configure-store'
import Router from './router/router'

const dbg = debug('app:main')

const store = configureStore()

dbg('store=%o', store)

class app extends Component {
  render() {
    return (
      <div>
        <Provider store={store}>
          <div id="index-div">
            <Router />
          </div>
        </Provider>
      </div>
    )
  }
}
export default app

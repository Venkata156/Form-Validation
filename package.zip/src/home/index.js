import debug from 'debug'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {withRouter} from 'react-router-dom'
import React, {Component} from 'react'
import Paper from '@material-ui/core/Paper'
import Typography from '@material-ui/core/Typography'
import * as actions from '../layout/layout-redux'

const dbg = debug('app:nonsense:index')

class help extends Component {
  render() {
    dbg('render: props=%o', this.props)
    return (
      <Paper  elevation={5}>
        <Typography align="center" variant="headline" gutterBottom color="primary">
         Welcome to Home
        </Typography>
        <Typography align="center" variant="subheading" paragraph>
          Some Help documentation
          <br />
        </Typography>
      </Paper>
    )
  }

  componentWillMount() {
    dbg('cwm')
    this.props.setTitle('Help')
  }

  componentWillUnmount() {
    dbg('cwu')
  }
}

export default withRouter(
  connect(
    state => {
      dbg('connect: state=%o', state)
      return {
        layout: state.layout
      }
    },
    dispatch => {
      dbg('connect: actions=%o', actions)
      return bindActionCreators(actions, dispatch)
    }
  )(help)
)

import debug from 'debug'
import config from 'config'
import {createAction, handleActions} from 'redux-actions'
import {handle} from 'redux-pack'
import restActions from '../../web-helpr/feathers-actions'
import {openSnackbar} from '../../layout/layout-redux'

const dbg = debug(`lib:pathway-reducer[${resource}]`)

const url = config.apiHost
const {resource} = config.apiResource.pathway

const INDEX = 'FETCH_PATHWAYS'
const FETCH_USER_PATHWAYS = 'FETCH_USER_PATHWAYS'
const CLEAR_DATA = 'CLEAR_DATA'

const clear = createAction(CLEAR_DATA)
const pathwayActions = restActions({url, resource})
const init = {
  query: {
    limit: 1000,
    offset: 0,
    sort: {field: null, isAscending: true}
  },
  rows: null,
  count: 0,
  active: false,
  more: true,
  currentPage: 0,
  totalPages: 0,
  item: null,
  pathwaydashboard: [],
  result: null
}

export default function({onFailure}) {
  async function getPathways({dispatch, query, url}) {
    const result = await dispatch({type: INDEX, promise: pathwayActions.index({query, url})})
    dbg('get: result=%o', result)
    if (result.error) {
      onFailure({dispatch, result})
    }
  }

  return {
    actions: {
      fetchPathways: url => {
        dbg('action: handle-refresh: fetch-pathways')
        return dispatch => {
          const query = {limit: 20}
          getPathways({dispatch, query, url})
        }
      },
      showSuccessSnackbar: ({message}) => {
        dbg('action: handle-refresh: show-message')
        return dispatch => {
          dispatch(openSnackbar(message))
        }
      },
      handleClear: () => {
        dbg('action: handle-clear')
        return dispatch => {
          dispatch(clear())
        }
      }
    },

    reducer: handleActions(
      {
        [INDEX]: (state, action) => {
          dbg('reducer: index: state=%o, action=%o', state, action)
          return handle(state, action, {
            start: () => ({
              ...state,
              active: true
            }),
            success: () => {
              return {
                ...state,
                ...action.payload,
                pathwaydashboard: [],
                active: false
              }
            }
          })
        },
        [FETCH_USER_PATHWAYS]: (state, action) => {
          dbg('reducer: index: state=%o, action=%o', state, action)
          return handle(state, action, {
            start: () => ({
              ...state,
              active: true
            }),
            success: () => {
              return {
                ...state,
                ...action.payload,
                pathwaydashboard: [],
                active: false
              }
            }
          })
        },
        [CLEAR_DATA]: (state, action) => {
          dbg('reducer: clear: state=%o, action=%o', state, action)
          return {
            ...init
          }
        }
      },
      init
    )
  }
}

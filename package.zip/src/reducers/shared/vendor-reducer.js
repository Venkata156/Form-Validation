import {openSnackbar} from '../../layout/layout-redux'
import vendorDetailsreducer, {url} from '../vendor-details-reducer'

export default vendorDetailsreducer({
  onSuccess: ({dispatch}) => dispatch(openSnackbar('success')),
  onFailure: ({dispatch, result}) =>
    dispatch(openSnackbar(result.message || result.payload.message))
})
export {url}

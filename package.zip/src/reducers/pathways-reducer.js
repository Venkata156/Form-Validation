import config from 'config'
import getReduxPage from '../shared/redux-page'
import getFeathersActions from '../web-helpr/feathers-actions'
import {openSnackbar} from '../layout/layout-redux'

const url = config.apiHost
const {resource} = config.apiResource.pathway
const actions = getFeathersActions({url, resource})
export default getReduxPage({
  resource,
  actions,
  limit: 5,
  onSuccess: ({dispatch, result}) => dispatch(openSnackbar(result.data.message || 'Success')),
  onFailure: ({dispatch, result}) =>
    dispatch(openSnackbar(result.message || result.payload.message))
})

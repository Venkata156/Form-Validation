import debug from 'debug'
import config from 'config'
import {handleActions, createAction} from 'redux-actions'
import {handle} from 'redux-pack'
import restActions from '../web-helpr/feathers-actions'

const url = config.apiHost
const {resource} = config.apiResource.vendor
const dbg = debug(`lib:vendor-reducer[${resource}]`)
const INDEX = 'FETCH_DATA'
const ALL_INDEX = 'FETCH_ALL_DATA'

const vendorActions = restActions({url, resource})
const init = {
  query: {
    limit: 1000,
    offset: 0,
    sort: {field: null, isAscending: true}
  },
  rows: null,
  count: 0,
  active: false,
  more: true,
  currentPage: 0,
  totalPages: 0,
  item: null,
  allVendors: [],
}
const allVendor =[{name:'vendor1',address:'mode'},
                  {name:'vendor2',address:'mode'}]
export default function({onFailure}) {
  async function getVendors({dispatch, query}) {
    const result = await dispatch({type: INDEX, promise: vendorActions.index({query})})
    dbg('get: result=%o', result)
    if (result.error) {
      onFailure({dispatch, result})
    }
  }

  async function getAllVendors({dispatch, query}) {
    const result = await dispatch({type: ALL_INDEX, promise: vendorActions.index({query})})
    dbg('get_all_Vendors: result=%o', result)
    if (result.error) {
      onFailure({dispatch, result})
    }
  }

  return {
    actions: {
      fetchVendors: () => {
        dbg('action: handle-refresh: fetch-Vendors')
        return dispatch => {
          const query = {
            limit: 10,
            offset: 0
          }
          getVendors({dispatch, query})
        }
      },
      fetchAllVendors: () => {
        dbg('action: handle-refresh: fetch-Vendors')
        return dispatch => {
          const query = {limit: 1000, offset: 0} // fetch to the maximum allowed
          getAllVendors({dispatch, query})
        }
      }
    },

    reducer: handleActions(
      {
        [INDEX]: (state, action) => {
          dbg('reducer: index: state=%o, action=%o', state, action)
          return handle(state, action, {
            start: () => ({
              ...state,
              active: true,
              allVendors:allVendor
            }),
            success: () => {
              return {
                ...state,
                ...action.payload,
                allVendors:allVendor,
                active: false
              }
            }
          })
        },
        [ALL_INDEX]: (state, action) => {
          dbg('reducer: all_index: state=%o, action=%o', state, action)
          return handle(state, action, {
            start: () => ({
              ...state,
              active: true
            }),
            success: () => {
              return {
                ...state,
                allVendors: action.payload.rows,
                active: false
              }
            }
          })
        }
      },
      init
    )
  }
}
export {url}

import React, {Component} from 'react'
import _ from 'lodash'
import {withStyles} from '@material-ui/core/styles'
import Snackbar from '@material-ui/core/Snackbar'
import Button from '@material-ui/core/Button'
import IconButton from '@material-ui/core/IconButton'
import CloseIcon from '@material-ui/icons/Close'
import debug from 'debug'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as actions from '../layout/layout-redux'
// import SuccessIcon from '../images/icn-success.png'
// import ErrorIcon from '../images/icn-error.png'

const dbg = debug('app:layout:snackbar')
const styles = theme => {
  return {
    container: {
      display: 'flex',
      flexGrow: 1
    },
    inputlabel: theme.palette.inputLabel,
    successMsg: {
      height: '54px',
      width: 'max-content',
      backgroundColor: '#FFFFFF',
      boxShadow: '0 2px 4px 0 rgba(0,0,0,0.12)',
      color: '#5F606E',
      fontSize: '16px',
      fontWeight: 'bold',
      fontFamily: 'arial',
      maxWidth: '598px'
    },
    successIcon: {
      height: '54px',
      width: '54px',
      backgroundColor: '#3C9D2E'
    },
    successBorder: {
      border: '1.5px solid #3C9D2E'
    },
    errorBorder: {
      border: '1.5px solid #CE0000'
    }
  }
}
class snackbar extends Component {
  constructor(props) {
    super(props)
    this.handleRequestClose = this.handleRequestClose.bind(this)
  }
  render() {
    const {layout, classes} = this.props
    let open = false
    const borderClass = open ? (isError ? classes.errorBorder : classes.successBorder) : ''
    const getMessage = (color, error) => {
      return (
        <span id="client-snackbar">
          <Button
            style={{
              backgroundColor: `${color}`,
              marginLeft: '-25px',
              marginRight: '20px',
              padding: '1px'
            }}
            size="small"
            disabled
          >
            <IconButton aria-label="message-icon">
              <img src={error ? '' : ''} />
            </IconButton>
          </Button>
          {''}
        </span>
      )
    }
    return (
      <Snackbar
        open={open}
        autoHideDuration={10000}
        message={
          open ? (isError ? getMessage('#CE0000', isError) : getMessage('#3C9D2E', isError)) : ''
        }
        ContentProps={{
          classes: {
            root: `${classes.successMsg} ${borderClass}`
          }
        }}
        onClose={(event, reason) => this.handleRequestClose(event, reason)}
        action={[
          <IconButton
            key="close"
            aria-label="Close"
            color="#7B7B85"
            onClick={(event, reason) => this.handleRequestClose(event, reason)}
          >
            <CloseIcon />
          </IconButton>
        ]}
      />
    )
  }

  handleRequestClose(event, reason) {
    dbg('handle-request-close: event=%o, reason=%o', event, reason)
    this.props.closeSnackbar()
  }
}

export default connect(
  state => {
    dbg('connect: state=%o', state)
    return {
      layout: state.layout
    }
  },
  dispatch => {
    dbg('connect: actions=%o', actions)
    return bindActionCreators(actions, dispatch)
  }
)(withStyles(styles)(snackbar))

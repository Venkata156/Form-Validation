import React, {Component} from 'react'
import config from 'config'
import {MuiThemeProvider, withStyles} from '@material-ui/core/styles'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {Switch, Route, withRouter} from 'react-router-dom'
import debug from 'debug'
import _ from 'lodash'
import Grid from '@material-ui/core/Grid'
import Home from '../home'
import help from '../help'
import '../App.css'
import TopNavContainer from '../header'
import SnackbarContainer from '../snackbar'
import Footer from '../footer'
import vendor from '../vendor'
import {getSessionStorage, addInsessionStorage} from '../shared/util'
import * as layoutActions from '../layout/layout-redux'
import {SESSION_KEYS} from '../constants/constant'
import {blueTheme} from './get-theme'
import { relative } from 'path';

const dbg = debug('app:layout')

const styles = theme => ({
  layoutRoot: {
    flexGrow: 1,
    minHeight: '91vh'
  },
  container: {
    display: 'grid',
    'flex-direction': 'column',
    //height: '100%',
    '@global': {
      a: {
        textDecoration: 'none',
        '&:visited': {
          color: theme.palette.primary[500]
        }
      }
    }
  },
  middle: {
    // flex: 'auto',
    position: 'relative',
    //'overflow-y': 'auto',
    paddingTop: 100,
    padding: 40
    //height: '100%'
  },
  top: {
    display: 'flex',
    flexDirection: 'row'
    // position: 'none'
  },
  ends: {
    // 'flex-shrink': 0,
    display: 'flex',
    flexDirection: 'row'
  },
  adjustMargin: {
    marginTop: '0'
  },
  fixedHeaderTop: {
    width: '100%'
  },
  fixedHeaderbottom: {
    width: '100%'
  }
})

class layout extends Component {
  constructor(props) {
    super(props)
    const storageToken =
      !_.isNil(JSON.parse(getSessionStorage(SESSION_KEYS.UserAuthToken))) &&
      !_.isEmpty(JSON.parse(getSessionStorage(SESSION_KEYS.UserAuthToken)))
        ? true
        : false
    this.state = {
      reload: 0,
      storageToken: storageToken,
      currentpath: ''
    }
    this.handleReload = this.handleReload.bind(this)
    this.clearUserTimeout = this.clearUserTimeout.bind(this)
  }
  componentDidMount() {
    //this.props.fetchTermsContent({url})
    if (typeof window !== 'undefined') {
      window.addEventListener(
        'storage',
        () => {
          const storageToken =
            !_.isNil(JSON.parse(getSessionStorage(SESSION_KEYS.UserAuthToken))) &&
            !_.isEmpty(JSON.parse(getSessionStorage(SESSION_KEYS.UserAuthToken)))
              ? true
              : false

          this.setState({storageToken: storageToken})
        },
        false
      )
    }
  }

  componentWillUnmount() {
    this.clearUserTimeout()
  }

  handleReload() {
    this.setState(prevState => ({
      reload: prevState.reload + 1
    }))
  }
  componentWillReceiveProps(nextProps) {
    this.setState({currentpath: nextProps.location.pathname})
  }

  clearUserTimeout() {
    if (this.timeoutHandle) {
      clearTimeout(this.timeoutHandle)
      this.timeoutHandle = null
    }
  }

  render() {
    dbg('props=%o', this.props)
    const {classes} = this.props
    var sessionExpTime
    const {history, logout} = this.props

    return (
      <MuiThemeProvider theme={blueTheme}>
       
          <Grid container spacing={0}>
              <Grid
                item
                xl={12}
                lg={12}
                md={12}
                sm={12}
                xs={12} 
              >
                <TopNavContainer />
              </Grid>
            <Grid item xl={12} lg={12} md={12} sm={12} xs={12} className={classes.layoutRoot} 
            style={{ position:'relative',
            top:'80px'}}>
              <Switch>
                <Route exact path="/" component={Home} />
                <Route path="/help" component={help} />
                <Route path="/vendor" component={vendor} />
              </Switch>
            </Grid>
            <Grid item xl={12} lg={12} md={12} sm={12} xs={12}>
              {this.state.currentpath == '/termsofservice' ? null : <Footer />}
              <SnackbarContainer />
            </Grid>
          </Grid>
      </MuiThemeProvider>
    )
  }
}

export default withRouter(
  connect(
    state => {
      dbg('connect: state=%o', state)
      return {
        session: state.session,
      }
    },
    dispatch => {
      dbg('connect: actions=%o', layoutActions)
      return bindActionCreators({...layoutActions}, dispatch)
    }
  )(withStyles(styles)(layout))
)

// see: https://github.com/erikras/ducks-modular-redux
//
import {createAction, handleActions} from 'redux-actions'
import debug from 'debug'

const dbg = debug('app:layout:redux')

const TOGGLE_DRAWER = 'layout/toggle-drawer'
const CLOSE_DRAWER = 'layout/close-drawer'
const TOGGLE_HEALTHZ_DRAWER = 'layout/toggle-healthz-drawer'
const CLOSE_HEALTHZ_DRAWER = 'layout/close-healthz-drawer'
const SET_TITLE = 'layout/set-title'
const OPEN_SNACKBAR = 'layout/open-snackbar'
const CLOSE_SNACKBAR = 'layout/close-snackbar'
const OPEN_DIALOG = 'layout/open-dialog'
const CLOSE_DIALOG = 'layout/close-dialog'
const MENU_OPTION = 'layout/menu-option'
const COMM_DIALOG = 'layout/comm-dialog'

export const toggleDrawer = createAction(TOGGLE_DRAWER)
export const closeDrawer = createAction(CLOSE_DRAWER)
export const toggleHealthzDrawer = createAction(TOGGLE_HEALTHZ_DRAWER)
export const closeHealthzDrawer = createAction(CLOSE_HEALTHZ_DRAWER)
export const setTitle = createAction(SET_TITLE)
export const openSnackbar = createAction(OPEN_SNACKBAR)
export const closeSnackbar = createAction(CLOSE_SNACKBAR)
export const changeMenuOption = createAction(MENU_OPTION)
export const openDialog = createAction(OPEN_DIALOG)
export const closeDialog = createAction(CLOSE_DIALOG)
export const commDialog = createAction(COMM_DIALOG)

export default handleActions(
  {
    [TOGGLE_HEALTHZ_DRAWER]: (state, action) => {
      dbg('reducer: toggle-drawer: state=%o, action=%o', state, action)
      return {
        ...state,
        isHealthzDrawerOpen: !state.isHealthzDrawerOpen
      }
    },
    [CLOSE_HEALTHZ_DRAWER]: (state, action) => {
      dbg('reducer: close-drawer: state=%o, action=%o', state, action)
      return {
        ...state,
        isHealthzDrawerOpen: false
      }
    },
    [TOGGLE_DRAWER]: (state, action) => {
      dbg('reducer: toggle-drawer: state=%o, action=%o', state, action)
      return {
        ...state,
        isDrawerOpen: !state.isDrawerOpen
      }
    },
    [CLOSE_DRAWER]: (state, action) => {
      dbg('reducer: close-drawer: state=%o, action=%o', state, action)
      return {
        ...state,
        isDrawerOpen: false
      }
    },
    [MENU_OPTION]: (state, action) => {
      dbg('reducer: menu-option: state=%o, action=%o', state, action)
      return {
        ...state,
        isMenuOption: action.payload
      }
    },
    [SET_TITLE]: (state, action) => {
      dbg('reducer: set-title: state=%o, action=%o', state, action)
      return {
        ...state,
        title: action.payload
      }
    },
    [OPEN_SNACKBAR]: (state, action) => {
      dbg('reducer: open-snackbar: state=%o, action=%o', state, action)
      return {
        ...state,
        snackbar: {
          open: true,
          message: action.payload
        }
      }
    },
    [CLOSE_SNACKBAR]: (state, action) => {
      dbg('reducer: close-snackbar: state=%o, action=%o', state, action)
      return {
        ...state,
        snackbar: {
          open: false,
          message: ''
        }
      }
    },
    [OPEN_DIALOG]: (state, action) => {
      dbg('reducer: open-dialog: state=%o, action=%o', state, action)
      return {
        ...state,
        dialog: {
          open: true,
          message: action.payload
        }
      }
    },
    [CLOSE_DIALOG]: (state, action) => {
      dbg('reducer: close-dialog: state=%o, action=%o', state, action)
      return {
        ...state,
        dialog: {
          open: false,
          message: null,
          reason: action.payload
        }
      }
    },
    [COMM_DIALOG]: (state, action) => {
      dbg('reducer: comm-dialog : state=%o, action=%o', state, action)
      return {
        ...state,
        isCommDialog: action.payload
      }
    }
  },
  {
    isDrawerOpen: false,
    isHealthzDrawerOpen: false,
    title: '',
    snackbar: {
      open: false,
      message: null
    },
    isDialogOpen: false,
    dialog: {
      open: false,
      message: null,
      reason: null
    },
    isMenuOption: '0',
    isCommDialog: true
  }
)

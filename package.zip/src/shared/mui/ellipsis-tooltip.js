import React from 'react'
import PropTypes from 'prop-types'
import {withStyles} from '@material-ui/core/styles'
//import Tooltip from '@material-ui/core/Tooltip'
import debug from 'debug'

const dbg = debug('lib:ellipsis-tooltip')

const styles = () => ({
  toolTipText: {
    minWidth: '83px',
    maxWidth: '500px',
    color: '#fff',
    '&>div': {
      fontSize: '16px',
      borderTop: '1px solid transparent',
      borderBottom: '2px solid transparent',
      fontFamily: 'Open Sans'
    }
  }
})

const EllipsisTooltip = props => {
  dbg('props=%o', props)
  //const {key, id, content, thresholdCharacters, classes} = props
  const {content, thresholdCharacters} = props

  return (
    <div>
      {/* <Tooltip
      //   key={key}
      //   id={id}
      //   title={content}
      //   PopperProps={{
      //     className: classes.toolTipText
      //   }}
      //   placement="bottom"
      // > */}
      <div title={content}>
        {content.length > thresholdCharacters ? (
          <span>{content.substring(0, thresholdCharacters) + '...'} </span>
        ) : (
          <span>{content}</span>
        )}
      </div>
      {/* </Tooltip> */}
    </div>
  )
}

EllipsisTooltip.propTypes = {
  key: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  content: PropTypes.string.isRequired,
  thresholdCharacters: PropTypes.number
}

export default withStyles(styles)(EllipsisTooltip)

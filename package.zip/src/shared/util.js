import _ from 'lodash'
import debug from 'debug'
import {SESSION_KEYS} from './../constants/constant'

const dbg = debug('app:shared:util')

export function addInsessionStorage(key, data, stringify = true) {
  if (!_.isNil(key) && stringify) {
    sessionStorage.setItem(key, JSON.stringify(data))
    return true
  } else {
    sessionStorage.setItem(key, data)
    return true
  }
}
export function removeFromSessionStorage(key) {
  if (!_.isNil(key)) {
    sessionStorage.removeItem(key)
    return true
  }
  return false
}

export function isSessionAlive(session) {
  return !_.isNil(session) && session.active
}

export function isClientUserIdSet() {
  return !_.isNil(getSessionStorage(SESSION_KEYS.UserClientId))
}

export function getSessionStorage(key) {
  if (!_.isNil(key)) {
    return sessionStorage.getItem(key)
  }
}

export function addNavigatedUrlToSession(match, key) {
  let UserLastAccessedUrl = getSessionStorage(key)
  if (!_.isNil(UserLastAccessedUrl)) {
    sessionStorage.removeItem(key)
    sessionStorage.setItem(key, match.url)
  } else {
    sessionStorage.setItem(key, '/landingpage')
  }
}

export function extractErrorMessage(result) {
  if (!_.isNil(result.payload)) {
    if (
      !_.isNil(result.payload.response) &&
      !_.isNil(result.payload.response.data) &&
      !_.isNil(result.payload.response.data.error)
    ) {
      return result.payload.response.data.error
    } else if (!_.isNil(result.payload.message)) {
      return result.payload.message
    } else if (!_.isNil(result.payload.data.status)) return result.payload.data.status
  }
  if (!_.isNil(result.message)) {
    return result.message
  }

  return null
}

export function isJson(item) {
  item = typeof item !== 'string' ? JSON.stringify(item) : item
  try {
    item = JSON.parse(item)
  } catch (err) {
    dbg('isjon:error=%o', err)
    return false
  }
  if (
    (typeof item === 'object' || typeof item === 'number' || typeof item === 'string') &&
    item !== null &&
    item !== undefined
  ) {
    return true
  }
  return false
}
export function isInvalidEmail(value) {
  return value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value) ? true : false
}

export function setAxiosHeader(axios) {
  const token = JSON.parse(getSessionStorage(SESSION_KEYS.UserAuthToken))
  const accessToken = JSON.parse(getSessionStorage(SESSION_KEYS.AccessToken))

  // Adding Bearer token and x-art-header for every request
  axios.defaults.headers.common['x-art-header'] = token
  // axios.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`

  axios.defaults.headers.common['x-art-auth'] = accessToken //used for external-user-registration

  axios.defaults.headers.common['id_token'] = token //_.replace(token, /"/g, '')
  axios.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`
  axios.defaults.headers.common['Content-Type'] = 'application/json'
  axios.defaults.headers.common['Accept'] = 'application/json'
  return axios
}

export function checkTermsAccepted(path) {
  if (_.toLower(path).indexOf('unauthorized') === -1) {
    const isUserLoggedIn = getSessionStorage(SESSION_KEYS.LoggedInUserId)
    if (_.isNil(isUserLoggedIn)) {
      if (!_.eq(path, '/')) window.location.hash = '/'
    } else {
      const isTermsAccepted = JSON.parse(getSessionStorage(SESSION_KEYS.UserTermsAcceptedDate))
      if (!_.eq(path, '/') && !_.eq(path, '/termsofservice')) {
        if (_.isNil(isTermsAccepted)) {
          window.location.hash = '/termsofservice'
        }
      }
      return
    }
  } else {
    return
  }
}
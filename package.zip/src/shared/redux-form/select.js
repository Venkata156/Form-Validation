import React from 'react'
import FormControl from '@material-ui/core/FormControl'
import FormHelperText from '@material-ui/core/FormHelperText'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import MenuItem from '@material-ui/core/MenuItem'
import Select from '@material-ui/core/Select'
import debug from 'debug'
import {withStyles} from '@material-ui/core/styles'
import _ from 'lodash'

const dbg = debug('lib:mui-helpr:redux-form:select')

const styles = theme => ({
  dropdown: theme.palette.dropdown.root,
  dropdownMenu: theme.palette.dropdown.dropdownMenu,
  dropdownIcon: theme.palette.dropdown.icon,
  dropdownDisabled: theme.palette.dropdown.disabled,
  formControl: {},
  helperText: {marginBottom: '-15px'},
  menu: theme.palette.menuListText
})

const SelectField = ({
  label,
  input: {name, value, onChange},
  meta: {touched, error, warning},
  options,
  className,
  classes,
  disabled
}) => {
  dbg('args=%o', arguments)
  const _error = touched && (error || warning)
  const items = []
  for (const key in options) {
    items.push(
      <MenuItem key={key} value={key} className={classes.menu}>
        {options[key]}
      </MenuItem>
    )
  }
  let dropdownClass = {
    root: classes.dropdown,
    selectMenu: classes.dropdownMenu,
    icon: classes.dropdownIcon,
    disabled: classes.dropdownDisabled
  }
  if (!_.isNil(className) && _.isObject(className)) dropdownClass = className
  return (
    <FormControl className={classes.formControl} error={_error} fullWidth={true}>
      {label && <InputLabel htmlFor={name}>{label || name}</InputLabel>}
      <Select
        value={value}
        onChange={onChange}
        input={<Input id={name} />}
        disabled={disabled}
        displayEmpty
        disableUnderline
        classes={dropdownClass}
      >
        {items}
      </Select>
      {_error && <FormHelperText className={classes.helperText}>{error || warning}</FormHelperText>}
    </FormControl>
  )
}

export default withStyles(styles)(SelectField)

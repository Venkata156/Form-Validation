import React, {Component} from 'react'

// helper for container components:
// https://css-tricks.com/learning-react-container-components/#article-header-id-6
// https://egghead.io/lessons/javascript-redux-fetching-data-on-route-change
// etc...
//
export default function({component, didMount, didUpdate}) {
  return class GetContainerClass extends Component {
    render() {
      // must use upper-case here!
      // https://reactjs.org/docs/jsx-in-depth.html#user-defined-components-must-be-capitalized
      //
      const Komponent = component
      return <Komponent {...this.props} />
    }

    componentDidMount() {
      didMount && didMount(this.props)
    }

    componentDidUpdate() {
      didUpdate && didUpdate(this.props)
    }
  }
}
